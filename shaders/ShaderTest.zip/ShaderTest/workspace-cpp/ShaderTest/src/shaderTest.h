//
//  shaderTest.h
//  OpenGL3ShaderTest
//
//  Created by Filipi Silva on 5/6/12.
//  Copyright (c) 2012 USP. All rights reserved.
//

#ifndef OpenGL3ShaderTest_shaderTest_h
#define OpenGL3ShaderTest_shaderTest_h

typedef enum{
	GEOTeapot = 0,
	GEOTeapotHiPoly,
	GEOSphere,
	GEOSphereHiPoly,
	GEOCube,
	GEOTorus,
	GEOCylinder,
	GEOMonkey,
	GEOPlane,
} GEOType;

void loadDefaultShaders();
void setShaders(const char* newVertexShader, 
				const char* newFragmentShader, 
				const char* newGeometryShader, 
				char useGeometry);

void setGeoType(GEOType newGEOType);

void setErrorCallbackFunction(void(*errorCallbackFunc)(char* string));

#endif
