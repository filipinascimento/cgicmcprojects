#include <stdio.h>
#include <stdlib.h>
#include "GL/glus.h"
#include <ctype.h>
#include <string.h>
#include "trackball.h"
#include "shaderTest.h"
#include <sys/types.h>
#include <dirent.h>

#if !defined(MIN)
#define MIN(A,B)	({ __typeof__(A) __a = (A); __typeof__(B) __b = (B); __a < __b ? __a : __b; })
#endif

#if !defined(MAX)
#define MAX(A,B)	({ __typeof__(A) __a = (A); __typeof__(B) __b = (B); __a < __b ? __b : __a; })
#endif

#define MAX_LIGHTS 3

//Light 
typedef struct {
	GLfloat direction[3];
	GLfloat ambientColor[4];
	GLfloat diffuseColor[4];
	GLfloat specularColor[4];
} LightProperties;

//Material
typedef struct {
	GLfloat ambientColor[4];
	GLfloat diffuseColor[4];
	GLfloat specularColor[4];
	GLfloat specularExponent;
} MaterialProperties;

//Light programabble shader addresses.
typedef struct {
	GLint directionLocation;
	GLint ambientColorLocation;
	GLint diffuseColorLocation;
	GLint specularColorLocation;
} LightLocations;

//Material programabble shader addresses.
typedef struct {
	GLint ambientColorLocation;
	GLint diffuseColorLocation;
	GLint specularColorLocation;
	GLint specularExponentLocation;
} MaterialLocations;

static GLfloat g_viewMatrix[16];
static GLfloat zoomFactor = 1.0f;
static GLfloat g_viewDimensions[2];

static GLUSshaderprogram g_program;

//Program Locations.
static GLint g_projectionMatrixLocation;
static GLint g_viewMatrixLocation;
static GLint g_modelMatrixLocation;
static GLint g_normalMatrixLocation;
static GLint g_vertexLocation;
static GLint g_normalLocation;
static GLint g_randomLocation;
static GLint g_texCoordsLocation;
static GLint g_textureLocation;
static GLint g_texture2Location;
static GLint g_normalMapLocation;
static GLint g_tangentLocation;
static GLint g_bitangentLocation;
static GLint g_normalLocation;
static GLint g_timeLocation;

static LightLocations g_lights[MAX_LIGHTS];
static MaterialLocations g_material;

// Vertex Buffer Objects
static GLuint g_verticesVBO;
static GLuint g_normalsVBO;
static GLuint g_randomVBO;
static GLuint g_texCoordsVBO;
static GLuint g_indicesVBO;
static GLuint g_tangentsVBO;
static GLuint g_bitangentsVBO;

// Vertex Attribute Object
static GLuint g_vao;

static GLuint g_numberVertices;
static GLuint g_numberIndices;

// Textures
static GLuint g_texture;
static GLuint g_texture2;
static GLuint g_normalMap;

//trackball rotations
static GLint gDollyPanStartPoint[2];
static GLfloat gTrackBallRotation[4];
static GLboolean gDolly;
static GLboolean gPan;
static GLboolean gTrackball;
static GLboolean g_shouldRotate;

// camera handling
static GLfloat worldRotation[4];
static GLfloat objectRotation[4];
// spin
static GLfloat rRot[3];
static GLfloat rVel[3];
static GLfloat rAccel[3];

static char* currentFragmentProgram;
static char* currentVertexProgram;
static char* currentGeometryProgram;
static char* lastError;

static GLboolean needsReload;
static GLboolean needsNewGeometry;
static GLboolean geometryShaderEnabled;
static GEOType geometryType;
static void (*currentErrorCallbackFunction)(char* string) = NULL;

static double currentTime = 0.0;

GLUSvoid destroyData(GLUSvoid);

LightProperties lights[3];

int selectedShaderIndex = 0;

MaterialProperties material = { { 0.7f, 0.2f, 0.2f, 1.0f }, { 0.7f, 0.2f, 0.2f, 1.0f }, { 1.0f, 0.8f, 0.8f, 1.0f },
		20.0f };

unsigned char compare_extension(char *filename, char *extension){
    /* Sanity checks */

    if(filename == NULL || extension == NULL)
        return 0;

    if(strlen(filename) == 0 || strlen(extension) == 0)
        return 0;

    if(strchr(filename, '.') == NULL || strchr(extension, '.') == NULL)
        return 0;

    /* Iterate backwards through respective strings and compare each char one at a time */

    for(int i = 0; i < strlen(filename); i++)
    {
        if(tolower(filename[strlen(filename) - i - 1]) == tolower(extension[strlen(extension) - i - 1]))
        {
            if(i == strlen(extension) - 1)
                return 1;
        } else
            break;
    }

    return 0;
}


void stripExtension(char* string){
	int stripPosition = strlen(string)-3;
	if(stripPosition>0){
		string[stripPosition-1] = '\0';
	}
}

void replaceExtension(char *fileName, char newExtension[4]){
	int stripPosition = strlen(fileName)-3;
	if(stripPosition>0){
		fileName[stripPosition+0] = newExtension[0];
		fileName[stripPosition+1] = newExtension[1];
		fileName[stripPosition+2] = newExtension[2];
	}
}

void updateCameraRotation(GLfloat *matrix) {
	if (gTrackBallRotation[0] != 0.0f) {
		glusMatrix4x4Rotatef(g_viewMatrix, gTrackBallRotation[0], gTrackBallRotation[1], gTrackBallRotation[2],
				gTrackBallRotation[3]);
	}
	glusMatrix4x4Rotatef(matrix, worldRotation[0], worldRotation[1], worldRotation[2], worldRotation[3]);
	glusMatrix4x4Rotatef(matrix, objectRotation[0], objectRotation[1], objectRotation[2], objectRotation[3]);

	rRot[0] = 0.0f;
	rRot[1] = 0.0f;
	rRot[2] = 0.0f;
}

void updateObjectRotationForTimeDelta(GLfloat aDeltaTime) {
	// update rotation based on vel and accel
	float rotation[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
	GLfloat fVMax = 2.0;
	short i;
	// do velocities
	for (i = 0; i < 3; i++) {
		rVel[i] += rAccel[i] * aDeltaTime * 30.0;

		if (rVel[i] > fVMax) {
			rAccel[i] *= -1.0;
			rVel[i] = fVMax;
		} else if (rVel[i] < -fVMax) {
			rAccel[i] *= -1.0;
			rVel[i] = -fVMax;
		}

		rRot[i] += rVel[i] * aDeltaTime * 30.0;

		while (rRot[i] > 360.0)
			rRot[i] -= 360.0;
		while (rRot[i] < -360.0)
			rRot[i] += 360.0;
	}
	rotation[0] = rRot[0];
	rotation[1] = 1.0f;
	addToRotationTrackball(rotation, objectRotation);
	rotation[0] = rRot[1];
	rotation[1] = 0.0f;
	rotation[2] = 1.0f;
	addToRotationTrackball(rotation, objectRotation);
	rotation[0] = rRot[2];
	rotation[2] = 0.0f;
	rotation[3] = 1.0f;
	addToRotationTrackball(rotation, objectRotation);
}

void setShaderIndex(int newIndex){
	DIR *dp;
	struct dirent *ep;

	GLUStextfile vertexSource;
	GLUStextfile fragmentSource;
	GLUStextfile geometrySource;
	char vertexPath[255] = "./shader/";
	char pixelPath[255] = "./shader/";
	char geometryPath[255] = "./shader/";
	dp = opendir("./shader/");
	GLUSboolean everythingOK = GLUS_FALSE;
	GLUSboolean haveGeometryShader = GLUS_FALSE;
	int i=0;
	if (dp != NULL) {
		while ((ep = readdir(dp))){
			char* fileName = ep->d_name;
			if(compare_extension(fileName,".vsh")){
				if(i==newIndex){
					replaceExtension(fileName,"vsh");
					strncat(vertexPath,fileName,255);
					replaceExtension(fileName,"fsh");
					strncat(pixelPath,fileName,255);
					replaceExtension(fileName,"gsh");
					strncat(geometryPath,fileName,255);

					everythingOK = glusLoadTextFile(vertexPath, &vertexSource);
					everythingOK = everythingOK && glusLoadTextFile(pixelPath, &fragmentSource);
					haveGeometryShader = glusLoadTextFile(geometryPath, &geometrySource);
					stripExtension(fileName);
					glfwSetWindowTitle(fileName);
				}
				i++;
			}
		}
		closedir(dp);
	} else{
		printf("Couldn't open the directory\n");
	}
	if(everythingOK){
		selectedShaderIndex = newIndex;
		setShaders(vertexSource.text, fragmentSource.text, geometrySource.text,
				haveGeometryShader);
	}else{
		selectedShaderIndex = -1;
		glfwSetWindowTitle("basic");
		loadDefaultShaders();
	}
	glusDestroyTextFile(&vertexSource);
	glusDestroyTextFile(&fragmentSource);
	//glusDestroyTextFile(&geometrySource);
}

//mouse

GLUSvoid glusKey(GLUSboolean pressed, GLUSint key) {
	if (pressed && key == 32) {
		g_shouldRotate = !g_shouldRotate;
	} else if (pressed && key == 61) {
		zoomFactor += 0.1 * zoomFactor;
	} else if (pressed && key == 45) {
		zoomFactor -= 0.1 * zoomFactor;
	}else if(pressed && key==97){ //A
		setShaderIndex(selectedShaderIndex-1);
	}else if(pressed && key==115){ //S
		setShaderIndex(selectedShaderIndex+1);
	}else if(pressed && key==122){ //Z
		geometryType--;
		geometryType = geometryType%(GEOPlane+1);
		needsNewGeometry = GL_TRUE;
	}else if(pressed && key==120){ //X
		geometryType++;
		geometryType = geometryType%(GEOPlane+1);
		needsNewGeometry = GL_TRUE;
	}
}
static int oldTicks = 0;
GLUSvoid glusMouseWheel(GLUSint buttons, GLUSint ticks, GLUSint xPos, GLUSint yPos) {

	zoomFactor += 0.1*zoomFactor*(ticks-oldTicks);
	oldTicks = ticks;
	if (zoomFactor < 0.1){
		zoomFactor = 0.1;
	}else if (zoomFactor > 10){
		zoomFactor = 10;
	}
}
GLUSvoid glusMouse(GLUSboolean pressed, GLUSint buttons, GLUSint xPos, GLUSint yPos) {
	if (!pressed) {
		if (gTrackball) { // end trackball
			gTrackball = GL_FALSE;
			if (gTrackBallRotation[0] != 0.0) {
				addToRotationTrackball(gTrackBallRotation, worldRotation);
			}
			gTrackBallRotation[0] = gTrackBallRotation[1] = gTrackBallRotation[2] = gTrackBallRotation[3] = 0.0f;
		}
	} else {
		gTrackball = GL_TRUE;
		yPos = g_viewDimensions[1] - yPos;
		startTrackball(xPos, yPos, 0, 0, g_viewDimensions[0], g_viewDimensions[1]);
	}
}

GLUSvoid glusMouseMove(GLUSint buttons, GLUSint xPos, GLUSint yPos) {
	if (buttons == 1) {
		yPos = g_viewDimensions[1] - yPos;
		if (gTrackball) {
			rollToTrackball(xPos, yPos, gTrackBallRotation);
		}
	}
}
void loadDefaultShaders() {
	GLUStextfile vertexSource;
	GLUStextfile fragmentSource;

	glusLoadTextFile("shader/phongPerPixel.vsh", &vertexSource);
	glusLoadTextFile("shader/phongPerPixel.fsh", &fragmentSource);
	// glusLoadTextFile("shader/basic.gsh", &geometrySource);
	currentGeometryProgram = NULL;
	free(currentVertexProgram);
	free(currentFragmentProgram);
	//free(currentGeometryProgram);
	free(lastError);

	currentVertexProgram = calloc(vertexSource.length + 1, sizeof(char));
	currentFragmentProgram = calloc(fragmentSource.length + 1, sizeof(char));
	//currentGeometryProgram = calloc(geometrySource.length,sizeof(char));
	lastError = NULL;

	//printf("teste1\n");
	strncpy(currentVertexProgram, vertexSource.text, vertexSource.length);
	strncpy(currentFragmentProgram, fragmentSource.text, fragmentSource.length);
	//strncpy(currentGeometryProgram, geometrySource.text, geometrySource.length);
	//printf("teste:%s\n",currentVertexProgram);
	//printf("teste:%s\n",currentFragmentProgram);

	//currentVertexProgram = calloc(1,sizeof(char));
	//currentFragmentProgram = calloc(1,sizeof(char));

	glusDestroyTextFile(&vertexSource);
	glusDestroyTextFile(&fragmentSource);
	//glusDestroyTextFile(&geometrySource);
	geometryShaderEnabled = GL_FALSE;
}

void setShaders(const char* newVertexShader, const char* newFragmentShader, const char* newGeometryShader,
		char useGeometry) {

	free(currentVertexProgram);
	free(currentFragmentProgram);
	free(currentGeometryProgram);
	free(lastError);

	currentVertexProgram = calloc(strlen(newVertexShader)+1, sizeof(char));
	currentFragmentProgram = calloc(strlen(newFragmentShader)+1, sizeof(char));
	if(newGeometryShader){
		currentGeometryProgram = calloc(strlen(newGeometryShader)+1, sizeof(char));
	}else{
		currentGeometryProgram = NULL;
	}
	lastError = NULL;

	strncpy(currentVertexProgram, newVertexShader, strlen(newVertexShader));
	strncpy(currentFragmentProgram, newFragmentShader, strlen(newFragmentShader));
	if(newGeometryShader){
		strncpy(currentGeometryProgram, newGeometryShader, strlen(newGeometryShader));
	}
	geometryShaderEnabled = useGeometry ? GL_TRUE : GL_FALSE;
	needsReload = GL_TRUE;
}

void setGeoType(GEOType newGEOType) {
	geometryType = newGEOType;
	needsNewGeometry = GL_TRUE;
}

void reloadData() {
	GLUSshape wavefrontObj;

	g_projectionMatrixLocation = glGetUniformLocation(g_program.program, "u_projectionMatrix");
	g_viewMatrixLocation = glGetUniformLocation(g_program.program, "u_viewMatrix");
	g_modelMatrixLocation = glGetUniformLocation(g_program.program, "u_modelMatrix");
	g_normalMatrixLocation = glGetUniformLocation(g_program.program, "u_normalMatrix");

	g_timeLocation = glGetUniformLocation(g_program.program, "u_time");

	g_lights[0].directionLocation = glGetUniformLocation(g_program.program, "u_lights[0].direction");
	g_lights[0].ambientColorLocation = glGetUniformLocation(g_program.program, "u_lights[0].ambientColor");
	g_lights[0].diffuseColorLocation = glGetUniformLocation(g_program.program, "u_lights[0].diffuseColor");
	g_lights[0].specularColorLocation = glGetUniformLocation(g_program.program, "u_lights[0].specularColor");

	g_lights[1].directionLocation = glGetUniformLocation(g_program.program, "u_lights[1].direction");
	g_lights[1].ambientColorLocation = glGetUniformLocation(g_program.program, "u_lights[1].ambientColor");
	g_lights[1].diffuseColorLocation = glGetUniformLocation(g_program.program, "u_lights[1].diffuseColor");
	g_lights[1].specularColorLocation = glGetUniformLocation(g_program.program, "u_lights[1].specularColor");

	g_lights[2].directionLocation = glGetUniformLocation(g_program.program, "u_lights[2].direction");
	g_lights[2].ambientColorLocation = glGetUniformLocation(g_program.program, "u_lights[2].ambientColor");
	g_lights[2].diffuseColorLocation = glGetUniformLocation(g_program.program, "u_lights[2].diffuseColor");
	g_lights[2].specularColorLocation = glGetUniformLocation(g_program.program, "u_lights[2].specularColor");

	g_material.ambientColorLocation = glGetUniformLocation(g_program.program, "u_material.ambientColor");
	g_material.diffuseColorLocation = glGetUniformLocation(g_program.program, "u_material.diffuseColor");
	g_material.specularColorLocation = glGetUniformLocation(g_program.program, "u_material.specularColor");
	g_material.specularExponentLocation = glGetUniformLocation(g_program.program, "u_material.specularExponent");

	g_vertexLocation = glGetAttribLocation(g_program.program, "a_vertex");
	g_normalLocation = glGetAttribLocation(g_program.program, "a_normal");
	g_randomLocation = glGetAttribLocation(g_program.program, "a_random");
	g_texCoordsLocation = glGetAttribLocation(g_program.program, "a_texCoords");

	g_textureLocation = glGetUniformLocation(g_program.program, "u_texture");
	g_texture2Location = glGetUniformLocation(g_program.program, "u_texture2");
	g_normalMapLocation = glGetUniformLocation(g_program.program, "u_normalMap");

	g_vertexLocation = glGetAttribLocation(g_program.program, "a_vertex");
	g_tangentLocation = glGetAttribLocation(g_program.program, "a_tangent");
	g_bitangentLocation = glGetAttribLocation(g_program.program, "a_bitangent");
	g_normalLocation = glGetAttribLocation(g_program.program, "a_normal");

	switch (geometryType) {
	case GEOTeapot:
		glusLoadObjFile("data/teapot.obj", &wavefrontObj);
		break;
	case GEOTeapotHiPoly:
		glusLoadObjFile("data/teapot-hipoly.obj", &wavefrontObj);
		break;
	case GEOMonkey:
		glusLoadObjFile("data/monkey.obj", &wavefrontObj);
		break;
	case GEOCube:
		glusCreateCubef(&wavefrontObj, 2.0f);
		break;
	case GEOCylinder:
		glusCreateCylinderf(&wavefrontObj, 2.0f, 1.0f, 20);
		break;
	case GEOSphere:
		glusCreateSpheref(&wavefrontObj, 2.0f, 10);
		break;
	case GEOSphereHiPoly:
		glusCreateSpheref(&wavefrontObj, 2.0f, 80);
		break;
	case GEOTorus:
		glusCreateTorusf(&wavefrontObj, 1.5f, 3.0f, 20, 20);
		break;
	case GEOPlane:
		glusCreatePlanef(&wavefrontObj, 2.0f);
		break;
	default:
		glusCreateCubef(&wavefrontObj, 2.0f);
		break;
	}

	//Object
	//glusCreateCubef(&wavefrontObj, 2.0f);

	//glusCreateSpheref(&wavefrontObj, 2.0f, 50);

	g_numberIndices = wavefrontObj.numberIndices;
	g_numberVertices = wavefrontObj.numberVertices;
	GLfloat* randomValues = malloc(g_numberVertices * 3 * sizeof(GLfloat));
	int i;

	for (i = 0; i < g_numberVertices * 3; i++) {
		randomValues[i] = rand() / (float) RAND_MAX;
	}

	glGenBuffers(1, &g_verticesVBO);
	glBindBuffer(GL_ARRAY_BUFFER, g_verticesVBO);
	glBufferData(GL_ARRAY_BUFFER, wavefrontObj.numberVertices * 4 * sizeof(GLfloat), (GLfloat*) wavefrontObj.vertices,
			GL_STATIC_DRAW);

	glGenBuffers(1, &g_normalsVBO);
	glBindBuffer(GL_ARRAY_BUFFER, g_normalsVBO);
	glBufferData(GL_ARRAY_BUFFER, wavefrontObj.numberVertices * 3 * sizeof(GLfloat), (GLfloat*) wavefrontObj.normals,
			GL_STATIC_DRAW);

	glGenBuffers(1, &g_texCoordsVBO);
	glBindBuffer(GL_ARRAY_BUFFER, g_texCoordsVBO);
	glBufferData(GL_ARRAY_BUFFER, wavefrontObj.numberVertices * 2 * sizeof(GLfloat), (GLfloat*) wavefrontObj.texCoords,
			GL_STATIC_DRAW);

	glGenBuffers(1, &g_tangentsVBO);
	glBindBuffer(GL_ARRAY_BUFFER, g_tangentsVBO);
	glBufferData(GL_ARRAY_BUFFER, wavefrontObj.numberVertices * 3 * sizeof(GLfloat), (GLfloat*) wavefrontObj.tangents,
			GL_STATIC_DRAW);

	glGenBuffers(1, &g_bitangentsVBO);
	glBindBuffer(GL_ARRAY_BUFFER, g_bitangentsVBO);
	glBufferData(GL_ARRAY_BUFFER, wavefrontObj.numberVertices * 3 * sizeof(GLfloat), (GLfloat*) wavefrontObj.bitangents,
			GL_STATIC_DRAW);

	glGenBuffers(1, &g_randomVBO);
	glBindBuffer(GL_ARRAY_BUFFER, g_randomVBO);
	glBufferData(GL_ARRAY_BUFFER, g_numberVertices * 3 * sizeof(GLfloat), randomValues, GL_STATIC_DRAW);

	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glGenBuffers(1, &g_indicesVBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g_indicesVBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, wavefrontObj.numberIndices * sizeof(GLuint), (GLuint*) wavefrontObj.indices,
			GL_STATIC_DRAW);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);

	glusDestroyShapef(&wavefrontObj);

	glGenVertexArrays(1, &g_vao);
	glBindVertexArray(g_vao);

	glBindBuffer(GL_ARRAY_BUFFER, g_verticesVBO);
	glVertexAttribPointer(g_vertexLocation, 4, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(g_vertexLocation);

	glBindBuffer(GL_ARRAY_BUFFER, g_normalsVBO);
	glVertexAttribPointer(g_normalLocation, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(g_normalLocation);

	glBindBuffer(GL_ARRAY_BUFFER, g_tangentsVBO);
	glVertexAttribPointer(g_tangentLocation, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(g_tangentLocation);

	glBindBuffer(GL_ARRAY_BUFFER, g_bitangentsVBO);
	glVertexAttribPointer(g_bitangentLocation, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(g_bitangentLocation);

	glBindBuffer(GL_ARRAY_BUFFER, g_texCoordsVBO);
	glVertexAttribPointer(g_texCoordsLocation, 2, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(g_texCoordsLocation);

	 glBindBuffer(GL_ARRAY_BUFFER, g_randomVBO);
	glVertexAttribPointer(g_randomLocation, 3, GL_FLOAT, GL_FALSE, 0, 0);
	glEnableVertexAttribArray(g_randomLocation);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, g_indicesVBO);

	//glUniform3fv(g_lights[0].directionLocation, 1, light.direction);
	glUniform4fv(g_lights[0].ambientColorLocation, 1, lights[0].ambientColor);
	glUniform4fv(g_lights[0].diffuseColorLocation, 1, lights[0].diffuseColor);
	glUniform4fv(g_lights[0].specularColorLocation, 1, lights[0].specularColor);

	glUniform4fv(g_lights[1].ambientColorLocation, 1, lights[1].ambientColor);
	glUniform4fv(g_lights[1].diffuseColorLocation, 1, lights[1].diffuseColor);
	glUniform4fv(g_lights[1].specularColorLocation, 1, lights[1].specularColor);

	glUniform4fv(g_lights[2].ambientColorLocation, 1, lights[2].ambientColor);
	glUniform4fv(g_lights[2].diffuseColorLocation, 1, lights[2].diffuseColor);
	glUniform4fv(g_lights[2].specularColorLocation, 1, lights[2].specularColor);

	glUniform4fv(g_material.ambientColorLocation, 1, material.ambientColor);
	glUniform4fv(g_material.diffuseColorLocation, 1, material.diffuseColor);
	glUniform4fv(g_material.specularColorLocation, 1, material.specularColor);
	glUniform1f(g_material.specularExponentLocation, material.specularExponent);

	glUniform1i(g_textureLocation, 0);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, g_texture);

	glUniform1i(g_texture2Location, 1);
	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, g_texture2);

	glUniform1i(g_normalMapLocation, 2);
	glActiveTexture(GL_TEXTURE2);
	glBindTexture(GL_TEXTURE_2D, g_normalMap);

}

GLUSboolean init(GLUSvoid) {
	LightProperties light0 = { { 0.433f, 0.433f, 0.433f }, { 0.1f, 0.1f, 0.1f, 1.0f }, { 1.0f, 1.0f, 1.0f, 1.0f }, {
			1.0f, 1.0f, 1.0f, 1.0f } };
	lights[0] = light0;

	LightProperties light1 = { { 0.845f, 0.169f, -0.507f }, { 0.0f, 0.0f, 0.0f, 1.0f }, { 0.4f, 0.1f, 0.1f, 1.0f }, {
			1.0f, 0.8f, 0.2f, 1.0f } };
	lights[1] = light1;

	LightProperties light2 = { { -0.433f, -0.433f, 0.433f }, { 0.0f, 0.0f, 0.0f, 1.0f }, { 0.3f, 0.3f, 0.6f, 1.0f }, {
			0.4f, 0.4f, 1.0f, 1.0f } };
	lights[2] = light2;

	gDollyPanStartPoint[0] = 0.0f;
	gDollyPanStartPoint[1] = 0.0f;

	gTrackBallRotation[0] = 0.0f;
	gTrackBallRotation[1] = 0.0f;
	gTrackBallRotation[2] = 0.0f;
	gTrackBallRotation[3] = 0.0f;
	gDolly = GL_FALSE;
	gPan = GL_FALSE;
	gTrackball = GL_FALSE;
	g_shouldRotate = GL_TRUE;
	zoomFactor = 2.0f;
	needsReload = GL_FALSE;
	geometryShaderEnabled = GL_FALSE;
	currentVertexProgram = NULL;
	currentFragmentProgram = NULL;
	currentGeometryProgram = NULL;
	lastError = NULL;
	geometryType = GEOSphere;
	loadDefaultShaders();

	glusBuildProgramFromSource(&g_program, (const GLUSchar**) &currentVertexProgram, NULL, NULL,
			geometryShaderEnabled ? (const GLUSchar**) (&currentGeometryProgram) : NULL,
			(const GLUSchar**) &currentFragmentProgram);

	glUseProgram(g_program.program);

	//#ifndef WINDOWS
	//	sranddev();
	//#endif

	GLUStgaimage image;

	glusLoadTgaImage("data/rock_color.tga", &image);
	glGenTextures(1, &g_texture);
	glBindTexture(GL_TEXTURE_2D, g_texture);
	glTexImage2D(GL_TEXTURE_2D, 0, image.format, image.width, image.height, 0, image.format, GL_UNSIGNED_BYTE,
			image.data);
	glusDestroyTgaImage(&image);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glBindTexture(GL_TEXTURE_2D, 0);

	glusLoadTgaImage("data/rock_normal.tga", &image);
	glGenTextures(1, &g_normalMap);
	glBindTexture(GL_TEXTURE_2D, g_normalMap);
	glTexImage2D(GL_TEXTURE_2D, 0, image.format, image.width, image.height, 0, image.format, GL_UNSIGNED_BYTE,
			image.data);
	glusDestroyTgaImage(&image);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glBindTexture(GL_TEXTURE_2D, 0);

	glusLoadTgaImage("data/crate.tga", &image);
	glGenTextures(1, &g_texture2);
	glBindTexture(GL_TEXTURE_2D, g_texture2);
	glTexImage2D(GL_TEXTURE_2D, 0, image.format, image.width, image.height, 0, image.format, GL_UNSIGNED_BYTE,
			image.data);
	glusDestroyTgaImage(&image);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glBindTexture(GL_TEXTURE_2D, 0);

	reloadData();

	glClearColor(0.8f, 0.8f, 0.8f, 1.0f);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);
	return GLUS_TRUE;
}

GLUSvoid reshape(GLUSint width, GLUSint height) {
	GLfloat projectionMatrix[16];

	glViewport(0, 0, width, height);

	g_viewDimensions[0] = width;
	g_viewDimensions[1] = height;

	glusPerspectivef(projectionMatrix, 70.0f, (GLfloat) width / (GLfloat) height, 1.0f, 100.0f);

	glUniformMatrix4fv(g_projectionMatrixLocation, 1, GL_FALSE, projectionMatrix);
}

GLUSboolean update(GLUSfloat time) {
	currentTime += time;
	if (needsReload || needsNewGeometry) {
		destroyData();
		if (glusBuildProgramFromSource(&g_program, (const GLUSchar**) &currentVertexProgram, NULL, NULL,
				geometryShaderEnabled ? (const GLUSchar**) (&currentGeometryProgram) : NULL,
				(const GLUSchar**) &currentFragmentProgram)) {

			glUseProgram(g_program.program);
			if (currentErrorCallbackFunction != NULL) {
				currentErrorCallbackFunction("Compiled Sucessful with no errors.");
			}
		} else {
			if (currentErrorCallbackFunction != NULL) {
				currentErrorCallbackFunction("Error Check Console.");
			}
		}
		reloadData();

		reshape(g_viewDimensions[0], g_viewDimensions[1]);
		needsReload = GL_FALSE;
		needsNewGeometry = GL_FALSE;
	}

	static GLfloat angle = 0.0f;

	GLfloat modelMatrix[16];
	GLfloat modelViewMatrix[16];
	GLfloat normalMatrix[9];
	GLfloat correctedLightDirection[3][3];

	correctedLightDirection[0][0] = lights[0].direction[0];
	correctedLightDirection[0][1] = lights[0].direction[1];
	correctedLightDirection[0][2] = lights[0].direction[2];

	correctedLightDirection[1][0] = lights[1].direction[0];
	correctedLightDirection[1][1] = lights[1].direction[1];
	correctedLightDirection[1][2] = lights[1].direction[2];

	correctedLightDirection[2][0] = lights[2].direction[0];
	correctedLightDirection[2][1] = lights[2].direction[1];
	correctedLightDirection[2][2] = lights[2].direction[2];

	glusMatrix4x4Identityf(g_viewMatrix);
	glusLookAtf(g_viewMatrix, 0.0f, 10.0f, 10.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);

	updateCameraRotation(g_viewMatrix);

	glusMatrix4x4MultiplyVector3f(correctedLightDirection[0], g_viewMatrix, correctedLightDirection[0]);
	glusVector3Normalizef(correctedLightDirection[0]);

	glusMatrix4x4MultiplyVector3f(correctedLightDirection[1], g_viewMatrix, correctedLightDirection[1]);
	glusVector3Normalizef(correctedLightDirection[1]);

	glusMatrix4x4MultiplyVector3f(correctedLightDirection[2], g_viewMatrix, correctedLightDirection[2]);
	glusVector3Normalizef(correctedLightDirection[2]);

	glusMatrix4x4Identityf(modelMatrix);
	glusMatrix4x4RotateRyf(modelMatrix, angle);
	glusMatrix4x4Scalef(modelMatrix, zoomFactor, zoomFactor, zoomFactor);

	glusMatrix4x4Multiplyf(modelViewMatrix, g_viewMatrix, modelMatrix);
	glusMatrix4x4ExtractMatrix3x3f(normalMatrix, modelViewMatrix);

	//if(!glusMatrix3x3Inversef(normalMatrix)){
	//	printf("ERROR NORMAL");
	//}

	glUniformMatrix4fv(g_viewMatrixLocation, 1, GL_FALSE, g_viewMatrix);
	glUniformMatrix4fv(g_modelMatrixLocation, 1, GL_FALSE, modelMatrix);
	glUniformMatrix3fv(g_normalMatrixLocation, 1, GL_FALSE, normalMatrix);
	glUniform3fv(g_lights[0].directionLocation, 1, correctedLightDirection[0]);
	glUniform3fv(g_lights[1].directionLocation, 1, correctedLightDirection[1]);
	glUniform3fv(g_lights[2].directionLocation, 1, correctedLightDirection[2]);
	glUniform1f(g_timeLocation, (GLfloat) currentTime);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glDrawElements(GL_TRIANGLES, g_numberIndices, GL_UNSIGNED_INT, 0);
	if (g_shouldRotate) {
		angle += 30.0f * time;
	}
	return GLUS_TRUE;
}

void setErrorCallbackFunction(void (*errorCallbackFunc)(char* string)) {
	currentErrorCallbackFunction = errorCallbackFunc;
	printf("Function SET: %p\n", currentErrorCallbackFunction);
}

GLUSvoid destroyData(GLUSvoid) {
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	if (g_verticesVBO) {
		glDeleteBuffers(1, &g_verticesVBO);
		g_verticesVBO = 0;
	}
	if (g_normalsVBO) {
		glDeleteBuffers(1, &g_normalsVBO);
		g_normalsVBO = 0;
	}
	if (g_texCoordsVBO) {
		glDeleteBuffers(1, &g_texCoordsVBO);
		g_texCoordsVBO = 0;
	}
	if (g_randomVBO) {
		glDeleteBuffers(1, &g_randomVBO);
		g_randomVBO = 0;
	}
	if (g_tangentsVBO) {
		glDeleteBuffers(1, &g_tangentsVBO);

		g_tangentsVBO = 0;
	}

	if (g_bitangentsVBO) {
		glDeleteBuffers(1, &g_bitangentsVBO);

		g_bitangentsVBO = 0;
	}
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	if (g_indicesVBO) {
		glDeleteBuffers(1, &g_indicesVBO);
		g_indicesVBO = 0;
	}
	glBindVertexArray(0);
	if (g_vao) {
		glDeleteVertexArrays(1, &g_vao);
		g_vao = 0;
	}
	glUseProgram(0);
	glusDestroyProgram(&g_program);
}

int main(int argc, char* argv[]) {


	glusInitFunc(init);
	glusReshapeFunc(reshape);
	glusUpdateFunc(update);
	glusTerminateFunc(destroyData);
	glusPrepareContext(3, 2, GLUS_FORWARD_COMPATIBLE_BIT);
	glusPrepareMSAA(8);
	glusMouseMoveFunc(glusMouseMove);
	glusMouseFunc(glusMouse);
	glusMouseWheelFunc(glusMouseWheel);
	glusKeyFunc(glusKey);
	if (!glusCreateWindow("Shader Test", 640, 480, 24, 0, GLUS_FALSE)) {
		printf("Could not create window!\n");
	}
	glusRun();
	return 0;
}
