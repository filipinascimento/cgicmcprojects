MAKE AND RUN
---------------------------------

1. Please make sure, you have installed a Windows OpenGL 3.2 driver.
2. Install Eclipse IDE for C/C++ Developers and a GNU Compiler Collection for your operating system.
3. Extract this ZIP file and set the workspace-cpp folder as your Eclipse workspace.
4. ShaderTest and GLUS as projects
5. Set the build configuration in Eclipse to your operating system.
6. Build GLUS.
7. Build any of the examples.
8. The executables are located in the Binaries folder. Execute them directly or create a run configuration in Eclipse.


Based on examples by Norbert Nopper (nopper.tv)

COMMANDS
Mouse dragging: rotates
Mouse Wheel: Zoom In/Out

+/-:   Zoom In/Out
A/S:   Cycle shaders
z/X:   Cycle 3D models
Space: Toggle auto-rotation

New shaders can be added by placing them in the shader folder
Vertex Shader Extension: .vsh
Fragment Shader Extension: .fsh
Geometry Shader Extension: .gsh

---------------------------
Shader implemented uniforms:

uniform mat4 u_projectionMatrix;
uniform mat4 u_viewMatrix;
uniform mat4 u_modelMatrix;
uniform mat3 u_normalMatrix;
uniform float u_time;
uniform sampler2D u_texture; 
uniform sampler2D u_texture2; 

uniform	DiretionalLight u_lights[MAX_LIGHTS];
uniform	Material u_material;
...where
struct DiretionalLight
{
	vec3 direction;
	vec4 ambientColor;
	vec4 diffuseColor;
	vec4 specularColor;
};

struct Material
{
	vec4 ambientColor;
	vec4 diffuseColor;
	vec4 specularColor;
	float specularExponent;
};
------------------------
Vertex Shader In (attributes)
in vec4 a_vertex;
in vec3 a_normal;
in vec3 a_random;
in vec2 a_texCoords;
in vec3 a_tangent;
in vec3 a_bitangent;

Fragment Shader Out 
out vec4 fragColor;

