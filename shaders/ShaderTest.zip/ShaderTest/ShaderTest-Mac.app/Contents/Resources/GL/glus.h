/**
 * GLUS - OpenGL 3 and 4 Utilities. Copyright (C) 2010 - 2012 Norbert Nopper
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __glus_h_
#define __glus_h_

#ifdef __cplusplus
extern "C"
{
#endif

#ifndef __APPLE__
#define GLEW_STATIC
#include <GL/glew.h>
#else
#define GLFW_NO_GLU
#define GLFW_INCLUDE_GL3
#include "GL/glfw.h"
#endif

#ifndef GLUSAPIENTRY
#define GLUSAPIENTRY
#endif
#ifndef GLUSAPIENTRYP
#define GLUSAPIENTRYP GLUSAPIENTRY *
#endif
#ifndef GLUSAPI
#define GLUSAPI extern
#endif

typedef unsigned int GLUSenum;
typedef unsigned char GLUSboolean;
typedef unsigned int GLUSbitfield;
typedef signed char GLUSbyte;
typedef short GLUSshort;
typedef int GLUSint;
typedef int GLUSsizei;
typedef unsigned char GLUSubyte;
typedef unsigned short GLUSushort;
typedef unsigned int GLUSuint;
typedef float GLUSfloat;
typedef float GLUSclampf;
typedef double GLUSdouble;
typedef double GLUSclampd;
typedef char GLUSchar;

#ifdef __cplusplus
#define GLUSvoid void
#else
typedef void GLUSvoid;
#endif

#define GLUS_OK 0
#define GLUS_TRUE   1
#define GLUS_FALSE  0
#define GLUS_BACKWARD_COMPATIBLE_BIT    0x0000
#define GLUS_FORWARD_COMPATIBLE_BIT     0x0002
#define GLUS_VERTEX_SHADER              0x8B31
#define GLUS_FRAGMENT_SHADER            0x8B30
#define GLUS_TESS_EVALUATION_SHADER     0x8E87
#define GLUS_TESS_CONTROL_SHADER        0x8E88
#define GLUS_GEOMETRY_SHADER            0x8DD9

#define GLUS_ALPHA  	0x1906
#define GLUS_RGB    	0x1907
#define GLUS_RGBA   	0x1908
#define GLUS_LUMINANCE  0x1909

#define PIf		3.1415926535897932384626433832795f

// TODO Think about inline functions

// TODO Example Gamma correction
// TODO Example GLOW
// TODO Example Depth of Field
// TODO Example Motion Blur

typedef struct _GLUStextfile
{
    GLUSchar* text;

    GLUSint length;

} GLUStextfile;

typedef struct _GLUSbinaryfile
{
    unsigned char* binary;

    GLUSint length;

} GLUSbinaryfile;

typedef struct _GLUStgaimage
{
    GLUSushort width;

    GLUSushort height;

    GLUSubyte* data;

    GLUSenum format;

} GLUStgaimage;

typedef struct _GLUSshaderprogram
{
    GLUSuint program;

    GLUSuint vertex;

    GLUSuint control;

    GLUSuint evaluation;

    GLUSuint geometry;

    GLUSuint fragment;

} GLUSshaderprogram;

typedef struct _GLUSshape
{
    GLUSfloat* vertices;

    GLUSfloat* normals;

    GLUSfloat* tangents;

    GLUSfloat* bitangents;

    GLUSfloat* texCoords;

    GLUSfloat* allAttributes;

    GLUSuint* indices;

    GLUSuint numberVertices;

    GLUSuint numberIndices;

    GLUSenum mode;

} GLUSshape;
//
// Callback functions.
//
GLUSAPI GLUSvoid GLUSAPIENTRY glusInitFunc(GLUSboolean(*glusNewInit)(GLUSvoid));
GLUSAPI GLUSvoid GLUSAPIENTRY glusReshapeFunc(GLUSvoid(*glusNewReshape)(const GLUSint width, const GLUSint height));
GLUSAPI GLUSvoid GLUSAPIENTRY glusUpdateFunc(GLUSboolean(*glusNewUpdate)(const GLUSfloat time));
GLUSAPI GLUSvoid GLUSAPIENTRY glusTerminateFunc(GLUSvoid(*glusNewTerminate)(GLUSvoid));
GLUSAPI GLUSvoid GLUSAPIENTRY glusKeyFunc(GLUSvoid(*glusNewKey)(const GLUSboolean pressed, const GLUSint key));
GLUSAPI GLUSvoid GLUSAPIENTRY glusMouseFunc(GLUSvoid(*glusNewMouse)(const GLUSboolean pressed, const GLUSint button, const GLUSint xPos, const GLUSint yPos));
GLUSAPI GLUSvoid GLUSAPIENTRY glusMouseWheelFunc(GLUSvoid(*glusNewMouseWheel)(const GLUSint buttons, const GLUSint ticks, const GLUSint xPos, const GLUSint yPos));
GLUSAPI GLUSvoid GLUSAPIENTRY glusMouseMoveFunc(GLUSvoid(*glusNewMouseMove)(const GLUSint buttons, const GLUSint xPos, const GLUSint yPos));
//
// Window creation functions.
//
GLUSAPI GLUSvoid GLUSAPIENTRY glusPrepareContext(const GLUSint major, const GLUSint minor, const GLUSint flags);
GLUSAPI GLUSvoid GLUSAPIENTRY glusPrepareMSAA(const GLUSint numberSamples);
GLUSAPI GLUSvoid GLUSAPIENTRY glusPrepareNoResize(const GLUSboolean noResize);
GLUSAPI GLUSboolean GLUSAPIENTRY glusCreateWindow(const GLUSchar* title, const GLUSint width, const GLUSint height, const GLUSint depthBits, const GLUSint stencilBits, const GLUSboolean fullscreen);
GLUSAPI GLUSvoid GLUSAPIENTRY glusDestroyWindow(GLUSvoid);
GLUSAPI GLUSboolean GLUSAPIENTRY glusRun(GLUSvoid);
//
// Version check functions.
//
GLUSAPI GLUSboolean GLUSAPIENTRY glusIsSupported(const GLUSint major, const GLUSint minor);
//
// File, image loading functions.
//
GLUSAPI GLUSboolean GLUSAPIENTRY glusLoadTextFile(const GLUSchar* filename, GLUStextfile* textfile);
GLUSAPI GLUSvoid GLUSAPIENTRY glusDestroyTextFile(GLUStextfile* textfile);
GLUSAPI GLUSboolean GLUSAPIENTRY glusLoadBinaryFile(const GLUSchar* filename, GLUSbinaryfile* binaryfile);
GLUSAPI GLUSvoid GLUSAPIENTRY glusDestroyBinaryFile(GLUSbinaryfile* binaryfile);
GLUSAPI GLUSboolean GLUSAPIENTRY glusLoadTgaImage(const GLUSchar* filename, GLUStgaimage* tgaimage);
GLUSAPI GLUSvoid GLUSAPIENTRY glusDestroyTgaImage(GLUStgaimage* tgaimage);
//
// Vector functions.
//
GLUSAPI GLUSvoid GLUSAPIENTRY glusVector3Copyf(GLUSfloat result[3], const GLUSfloat vector[3]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusVector2Copyf(GLUSfloat result[2], const GLUSfloat vector[2]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusVector3AddVector3f(GLUSfloat result[3], const GLUSfloat vector0[3], const GLUSfloat vector1[3]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusVector2AddVector2f(GLUSfloat result[2], const GLUSfloat vector0[2], const GLUSfloat vector1[2]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusVector3SubtractVector3f(GLUSfloat result[3], const GLUSfloat vector0[3], const GLUSfloat vector1[3]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusVector2SubtractVector2f(GLUSfloat result[2], const GLUSfloat vector0[2], const GLUSfloat vector1[2]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusVector3MultiplyScalarf(GLUSfloat result[3], const GLUSfloat vector0[3], const GLUSfloat scalar);
GLUSAPI GLUSvoid GLUSAPIENTRY glusVector2MultiplyScalarf(GLUSfloat result[2], const GLUSfloat vector0[2], const GLUSfloat scalar);
GLUSAPI GLUSfloat GLUSAPIENTRY glusVector3Lengthf(const GLUSfloat vector[3]);
GLUSAPI GLUSfloat GLUSAPIENTRY glusVector2Lengthf(const GLUSfloat vector[2]);
GLUSAPI GLUSboolean GLUSAPIENTRY glusVector3Normalizef(GLUSfloat vector[3]);
GLUSAPI GLUSboolean GLUSAPIENTRY glusVector2Normalizef(GLUSfloat vector[2]);
GLUSAPI GLUSfloat GLUSAPIENTRY glusVector3Dotf(const GLUSfloat vector0[3], const GLUSfloat vector1[3]);
GLUSAPI GLUSfloat GLUSAPIENTRY glusVector2Dotf(const GLUSfloat vector0[2], const GLUSfloat vector1[2]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusVector3Crossf(GLUSfloat result[3], const GLUSfloat vector0[3], const GLUSfloat vector1[3]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusVector3GetQuaternionf(GLUSfloat result[4], const GLUSfloat vector[3]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusVector3GetPoint4f(GLUSfloat result[4], const GLUSfloat vector[3]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusVector2GetPoint3f(GLUSfloat result[3], const GLUSfloat vector[2]);
//
// Point functions.
//
GLUSAPI GLUSvoid GLUSAPIENTRY glusPoint4Copyf(GLUSfloat result[4], const GLUSfloat point[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusPoint3Copyf(GLUSfloat result[3], const GLUSfloat point[3]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusPoint4SubtractPoint4f(GLUSfloat result[3], const GLUSfloat point0[4], const GLUSfloat point1[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusPoint3SubtractPoint3f(GLUSfloat result[2], const GLUSfloat point0[3], const GLUSfloat point1[3]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusPoint4AddVector3f(GLUSfloat result[4], const GLUSfloat point[4], const GLUSfloat vector[3]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusPoint3AddVector2f(GLUSfloat result[3], const GLUSfloat point[3], const GLUSfloat vector[2]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusPoint4SubtractVector3f(GLUSfloat result[4], const GLUSfloat point[4], const GLUSfloat vector[3]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusPoint3SubtractVector2f(GLUSfloat result[3], const GLUSfloat point[3], const GLUSfloat vector[2]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusPoint4GetQuaternionf(GLUSfloat result[4], const GLUSfloat point[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusPoint4GetVector3f(GLUSfloat result[3], const GLUSfloat point[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusPoint3GetVector2f(GLUSfloat result[2], const GLUSfloat point[3]);
GLUSAPI GLUSfloat GLUSAPIENTRY glusPoint4Distancef(const GLUSfloat point0[4], const GLUSfloat point1[4]);
GLUSAPI GLUSfloat GLUSAPIENTRY glusPoint3Distancef(const GLUSfloat point0[3], const GLUSfloat point1[3]);
//
// Plane functions.
//
GLUSAPI GLUSvoid GLUSAPIENTRY glusPlaneCopyf(GLUSfloat result[4], const GLUSfloat plane[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusPlaneCreatef(GLUSfloat result[4], const GLUSfloat point[4], const GLUSfloat normal[3]);
GLUSAPI GLUSfloat GLUSAPIENTRY glusPlaneDistancef(const GLUSfloat plane[4], const GLUSfloat point[4]);
//
// Math functions
//
GLUSAPI GLUSfloat GLUSAPIENTRY glusMaxf(const GLUSfloat value0, const GLUSfloat value1);
GLUSAPI GLUSfloat GLUSAPIENTRY glusMinf(const GLUSfloat value0, const GLUSfloat value1);
GLUSAPI GLUSfloat GLUSAPIENTRY glusRadToDegf(const GLUSfloat radians);
GLUSAPI GLUSfloat GLUSAPIENTRY glusDegToRadf(const GLUSfloat degrees);
GLUSAPI GLUSfloat GLUSAPIENTRY glusMixf(const GLUSfloat value0, const GLUSfloat value1, const GLUSfloat t);
GLUSAPI GLUSfloat GLUSAPIENTRY glusClampf(const GLUSfloat value, const GLUSfloat min, const GLUSfloat max);
GLUSAPI GLUSfloat GLUSAPIENTRY glusLengthf(const GLUSfloat x, const GLUSfloat y, const GLUSfloat z);
//
// View, projection etc. functions.
//
GLUSAPI GLUSboolean GLUSAPIENTRY glusOrthof(GLUSfloat result[16], const GLUSfloat left, const GLUSfloat right, const GLUSfloat bottom, const GLUSfloat top, const GLUSfloat nearVal, const GLUSfloat farVal);
GLUSAPI GLUSboolean GLUSAPIENTRY glusFrustumf(GLUSfloat result[16], const GLUSfloat left, const GLUSfloat right, const GLUSfloat bottom, const GLUSfloat top, const GLUSfloat nearVal, const GLUSfloat farVal);
GLUSAPI GLUSboolean GLUSAPIENTRY glusPerspectivef(GLUSfloat result[16], const GLUSfloat fovy, const GLUSfloat aspect, const GLUSfloat zNear, const GLUSfloat zFar);
GLUSAPI GLUSvoid GLUSAPIENTRY glusLookAtf(GLUSfloat result[16], const GLUSfloat eyeX, const GLUSfloat eyeY, const GLUSfloat eyeZ, const GLUSfloat centerX, const GLUSfloat centerY, const GLUSfloat centerZ, const GLUSfloat upX, const GLUSfloat upY, const GLUSfloat upZ);
//
// Matrix functions.
//
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4Identityf(GLUSfloat matrix[16]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3Identityf(GLUSfloat matrix[9]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix2x2Identityf(GLUSfloat matrix[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4Copyf(GLUSfloat matrix[16], const GLUSfloat source[16], const GLUSboolean rotationOnly);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3Copyf(GLUSfloat matrix[9], const GLUSfloat source[9]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix2x2Copyf(GLUSfloat matrix[4], const GLUSfloat source[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4ExtractMatrix3x3f(GLUSfloat matrix[9], const GLUSfloat source[16]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4ExtractMatrix2x2f(GLUSfloat matrix[4], const GLUSfloat source[16]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3ExtractMatrix2x2f(GLUSfloat matrix[4], const GLUSfloat source[9]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4Multiplyf(GLUSfloat matrix[16], const GLUSfloat matrix0[16], const GLUSfloat matrix1[16]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3Multiplyf(GLUSfloat matrix[9], const GLUSfloat matrix0[9], const GLUSfloat matrix1[9]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix2x2Multiplyf(GLUSfloat matrix[4], const GLUSfloat matrix0[4], const GLUSfloat matrix1[4]);
GLUSAPI GLUSboolean GLUSAPIENTRY glusMatrix4x4Inversef(GLUSfloat matrix[16]);
GLUSAPI GLUSboolean GLUSAPIENTRY glusMatrix3x3Inversef(GLUSfloat matrix[9]);
GLUSAPI GLUSboolean GLUSAPIENTRY glusMatrix2x2Inversef(GLUSfloat matrix[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4InverseRigidBodyf(GLUSfloat matrix[16]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4Transposef(GLUSfloat matrix[16]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3Transposef(GLUSfloat matrix[9]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix2x2Transposef(GLUSfloat matrix[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4Translatef(GLUSfloat matrix[16], const GLUSfloat x, const GLUSfloat y, const GLUSfloat z);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3Translatef(GLUSfloat matrix[9], const GLUSfloat x, const GLUSfloat y);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4Rotatef(GLUSfloat matrix[16], const GLUSfloat angle, const GLUSfloat x, const GLUSfloat y, const GLUSfloat z);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3Rotatef(GLUSfloat matrix[9], const GLUSfloat angle, const GLUSfloat x, const GLUSfloat y, const GLUSfloat z);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix2x2Rotatef(GLUSfloat matrix[4], const GLUSfloat angle);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4RotateRxf(GLUSfloat matrix[16], const GLUSfloat angle);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3RotateRxf(GLUSfloat matrix[9], const GLUSfloat angle);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4RotateRyf(GLUSfloat matrix[16], const GLUSfloat angle);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3RotateRyf(GLUSfloat matrix[9], const GLUSfloat angle);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4RotateRzf(GLUSfloat matrix[16], const GLUSfloat angle);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3RotateRzf(GLUSfloat matrix[9], const GLUSfloat angle);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4RotateRzRxRyf(GLUSfloat matrix[16], const GLUSfloat anglez, const GLUSfloat anglex, const GLUSfloat angley);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3RotateRzRxRyf(GLUSfloat matrix[9], const GLUSfloat anglez, const GLUSfloat anglex, const GLUSfloat angley);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4Scalef(GLUSfloat matrix[16], const GLUSfloat x, const GLUSfloat y, const GLUSfloat z);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3Scalef(GLUSfloat matrix[9], const GLUSfloat x, const GLUSfloat y, const GLUSfloat z);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix2x2Scalef(GLUSfloat matrix[4], const GLUSfloat x, const GLUSfloat y);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4Shearf(GLUSfloat matrix[16], const GLUSfloat shxy, const GLUSfloat shxz, const GLUSfloat shyx, const GLUSfloat shyz, const GLUSfloat shzx, const GLUSfloat shzy);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3Shearf(GLUSfloat matrix[9], const GLUSfloat shxy, const GLUSfloat shxz, const GLUSfloat shyx, const GLUSfloat shyz, const GLUSfloat shzx, const GLUSfloat shzy);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix2x2Shearf(GLUSfloat matrix[4], const GLUSfloat shx, const GLUSfloat shy);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4MultiplyVector3f(GLUSfloat result[3], const GLUSfloat matrix[16], const GLUSfloat vector[3]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4MultiplyVector2f(GLUSfloat result[2], const GLUSfloat matrix[16], const GLUSfloat vector[2]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3MultiplyVector3f(GLUSfloat result[3], const GLUSfloat matrix[9], const GLUSfloat vector[3]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3MultiplyVector2f(GLUSfloat result[2], const GLUSfloat matrix[9], const GLUSfloat vector[2]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix2x2MultiplyVector2f(GLUSfloat result[2], const GLUSfloat matrix[4], const GLUSfloat vector[2]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4MultiplyPoint4f(GLUSfloat result[4], const GLUSfloat matrix[16], const GLUSfloat point[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3MultiplyPoint3f(GLUSfloat result[3], const GLUSfloat matrix[9], const GLUSfloat point[3]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4MultiplyPlanef(GLUSfloat result[4], const GLUSfloat matrix[16], const GLUSfloat plane[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix4x4GetEulerRzRxRyf(GLUSfloat angles[3], const GLUSfloat matrix[16]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3GetEulerRzRxRyf(GLUSfloat angles[3], const GLUSfloat matrix[9]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix3x3GetAnglef(GLUSfloat* angle, const GLUSfloat matrix[9]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusMatrix2x2GetAnglef(GLUSfloat* angle, const GLUSfloat matrix[4]);
//
// Quaternion functions.
//
GLUSAPI GLUSvoid GLUSAPIENTRY glusQuaternionIdentityf(GLUSfloat quaternion[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusQuaternionCopyf(GLUSfloat result[4], const GLUSfloat quaternion[4]);
GLUSAPI GLUSfloat GLUSAPIENTRY glusQuaternionNormf(const GLUSfloat quaternion[4]);
GLUSAPI GLUSboolean GLUSAPIENTRY glusQuaternionNormalizef(GLUSfloat quaternion[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusQuaternionAddQuaternionf(GLUSfloat result[4], const GLUSfloat quaternion0[4], const GLUSfloat quaternion1[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusQuaternionSubQuaternionf(GLUSfloat result[4], const GLUSfloat quaternion0[4], const GLUSfloat quaternion1[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusQuaternionMultiplyQuaternionf(GLUSfloat result[4], const GLUSfloat quaternion0[4], const GLUSfloat quaternion1[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusQuaternionConjugatef(GLUSfloat quaternion[4]);
GLUSAPI GLUSboolean GLUSAPIENTRY glusQuaternionInversef(GLUSfloat quaternion[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusQuaternionInverseUnitf(GLUSfloat quaternion[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusQuaternionRotatef(GLUSfloat quaternion[4], const GLUSfloat angle, const GLUSfloat x, const GLUSfloat y, const GLUSfloat z);
GLUSAPI GLUSvoid GLUSAPIENTRY glusQuaternionRotateRxf(GLUSfloat quaternion[4], const GLUSfloat angle);
GLUSAPI GLUSvoid GLUSAPIENTRY glusQuaternionRotateRyf(GLUSfloat quaternion[4], const GLUSfloat angle);
GLUSAPI GLUSvoid GLUSAPIENTRY glusQuaternionRotateRzf(GLUSfloat quaternion[4], const GLUSfloat angle);
GLUSAPI GLUSvoid GLUSAPIENTRY glusQuaternionRotateRzRxRyf(GLUSfloat quaternion[4], const GLUSfloat anglez, const GLUSfloat anglex, const GLUSfloat angley);
GLUSAPI GLUSvoid GLUSAPIENTRY glusQuaternionGetMatrix4x4f(GLUSfloat matrix[16], const GLUSfloat quaternion[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusQuaternionGetMatrix3x3f(GLUSfloat matrix[9], const GLUSfloat quaternion[4]);
GLUSAPI GLUSboolean GLUSAPIENTRY glusQuaternionGetPoint4f(GLUSfloat point[4], const GLUSfloat quaternion[4]);
GLUSAPI GLUSboolean GLUSAPIENTRY glusQuaternionGetVector3f(GLUSfloat vector[3], const GLUSfloat quaternion[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusQuaternionGetEulerRzRxRyf(GLUSfloat angles[3], const GLUSfloat quaternion[4]);
GLUSAPI GLUSvoid GLUSAPIENTRY glusQuaternionSlerpf(GLUSfloat result[16], const GLUSfloat quaternion0[4], const GLUSfloat quaternion1[4], const GLUSfloat t);
//
// Shader creation function.
//
GLUSAPI GLUSboolean GLUSAPIENTRY glusCreateProgramFromSource(GLUSshaderprogram* shaderProgram, const GLUSchar** vertexSource, const GLUSchar** controlSource, const GLUSchar** evaluationSource, const GLUSchar** geometrySource, const GLUSchar** fragmentSource);
GLUSAPI GLUSboolean GLUSAPIENTRY glusLinkProgram(GLUSshaderprogram* shaderProgram);
GLUSAPI GLUSboolean GLUSAPIENTRY glusBuildProgramFromSource(GLUSshaderprogram* shaderProgram, const GLUSchar** vertexSource, const GLUSchar** controlSource, const GLUSchar** evaluationSource, const GLUSchar** geometrySource, const GLUSchar** fragmentSource);
GLUSAPI GLUSvoid GLUSAPIENTRY glusDestroyProgram(GLUSshaderprogram* shaderprogram);
//
// Shape / geometry functions.
//
GLUSAPI GLUSboolean GLUSAPIENTRY glusCreatePlanef(GLUSshape* shape, const GLUSfloat halfExtend);
GLUSAPI GLUSboolean GLUSAPIENTRY glusCreateRectangularPlanef(GLUSshape* shape, const GLUSfloat horizontalExtend, const GLUSfloat verticalExtend);
GLUSAPI GLUSboolean GLUSAPIENTRY glusCreateSegmentedRectangularPlanef(GLUSshape* shape, const GLUSfloat horizontalExtend, const GLUSfloat verticalExtend, const GLUSuint rows, const GLUSuint columns);
GLUSAPI GLUSboolean GLUSAPIENTRY glusCreateDiscf(GLUSshape* shape, const GLUSfloat radius, const GLUSuint numberSlices);
GLUSAPI GLUSboolean GLUSAPIENTRY glusCreateCubef(GLUSshape* shape, const GLUSfloat halfExtend);
GLUSAPI GLUSboolean GLUSAPIENTRY glusCreateSpheref(GLUSshape* shape, const GLUSfloat radius, const GLUSuint numberSlices);
GLUSAPI GLUSboolean GLUSAPIENTRY glusCreateDomef(GLUSshape* shape, const GLUSfloat radius, const GLUSuint numberSlices);
GLUSAPI GLUSboolean GLUSAPIENTRY glusCreateTorusf(GLUSshape* shape, const GLUSfloat innerRadius, const GLUSfloat outerRadius, const GLUSuint numberSlices, const GLUSuint numberStacks);
GLUSAPI GLUSboolean GLUSAPIENTRY glusCreateCylinderf(GLUSshape* shape, const GLUSfloat halfExtend, const GLUSfloat radius, const GLUSuint numberSlices);
GLUSAPI GLUSboolean GLUSAPIENTRY glusCreateConef(GLUSshape* shape, const GLUSfloat halfExtend, const GLUSfloat radius, const GLUSuint numberSlices, const GLUSuint numberStacks);
GLUSAPI GLUSvoid GLUSAPIENTRY glusDestroyShapef(GLUSshape* shape);
//
// Model loading functions.
//
GLUSAPI GLUSboolean GLUSAPIENTRY glusLoadObjFile(const GLUSchar* filename, GLUSshape* shape);

#ifdef __cplusplus
}
#endif

#endif /*__glus_h_*/
